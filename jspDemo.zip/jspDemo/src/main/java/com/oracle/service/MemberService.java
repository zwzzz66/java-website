package com.oracle.service;

import com.oracle.mapper.MemberMapper;
import com.oracle.pojo.*;
import com.oracle.utils.DBUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.ibatis.session.SqlSession;

import java.util.List;
import java.util.UUID;

public class MemberService {


    public boolean login(Member member){

        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        Member memberPo = memberMapper.selectMemberByUserName(member.getName());
        if (memberPo == null){
            return false;
        }
        String pwd = DigestUtils.sha1Hex(member.getPwd());
        if (!memberPo.getPwd().equals(pwd)){
            return false;
        }
        member.setId(memberPo.getId());
        member.setPwd(null);
        return true;
    }

    public int register(Member member){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        int i = memberMapper.selectMemberCountByUserName(member.getName());
        if(i > 0){
            return 1;
        }
        member.setPwd(DigestUtils.sha1Hex(member.getPwd()));
        memberMapper.insertMember(member);
        String token = UUID.randomUUID().toString();
        sqlSession.commit();
        return 0;
    }
    public int selectUserCount(String username){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        int i = memberMapper.selectMemberCountByUserName(username);
        sqlSession.close();
        return i;
    }

    public int changePassword(String username,String oldPassword,String newPassword){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        String password = memberMapper.getOldPassword(username);
        oldPassword = DigestUtils.sha1Hex(oldPassword);
        newPassword = DigestUtils.sha1Hex(newPassword);
        if (oldPassword.equals(password)){
            memberMapper.changePassword(username,newPassword);
            sqlSession.commit();
            sqlSession.close();
            return 1;
        }else {
            return 0;
        }

    }
    public void addLoginCount(String username){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        memberMapper.addLoginCount(username);
        sqlSession.commit();
        sqlSession.close();
        return;
    }
    public void clearLoginCount(String username){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        memberMapper.clearLoginCount(username);
        sqlSession.commit();
        sqlSession.close();
        return;
    }

    public int selectLoginCount(String username){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        Integer count = memberMapper.selectLoginCount(username);
        sqlSession.close();
        return count;
    }

    public void InsertComment(String username,String comment,String time){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        Message message = new Message();
        message.setUsername(username);
        message.setComment(comment);
        message.setTime(time);
        System.out.print(username);
        memberMapper.InsertComment(message);
        sqlSession.commit();
        sqlSession.close();
    }

    public List<Message> getAllComments(){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        List<Message> MessageList = memberMapper.getAllComment();
        sqlSession.close();
        return MessageList;
    }

    public List<User> getAllUsers(){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        List<User> UserList = memberMapper.getAllUsers();
        sqlSession.close();
        return UserList;
    }

    public List<PrivateMessage> getPrivateMessage(String user1, String user2){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        PrivateUser privateUser = new PrivateUser();
        privateUser.setUser1(user1);
        privateUser.setUser2(user2);
        List<PrivateMessage> privateMessageList = memberMapper.getPrivateMessage(privateUser);
        System.out.print(privateMessageList);
        sqlSession.close();
        return privateMessageList;
    }
    public void addPrivateMessage(PrivateMessage privateMessage){
        SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
        MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
        memberMapper.addPrivateMessage(privateMessage);
        sqlSession.commit();
        sqlSession.close();
    }
}
