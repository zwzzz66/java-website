package com.oracle.utils;

public class PasswordUtils {

    // 密码复杂度检查
    public static boolean isPasswordComplex(String password) {
        if (password == null) {
            return false;
        }
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        if (password.length() < 8) {
            return false;
        }

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;

            if(hasUpper  && hasDigit && hasSpecial ||  hasLower && hasDigit && hasSpecial) {
                return true;
            }
        }

        return false;
    }
}
