package com.oracle.servlet;

import com.oracle.service.MemberService;
import com.oracle.utils.PasswordUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/changePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String oldPassword = req.getParameter("oldPassword");
        String newPassword = req.getParameter("newPassword");

        MemberService memberService = new MemberService();
        Integer i = memberService.selectUserCount(username);
        if (i == 0){
            req.setAttribute("changeError","用户不存在");
            req.getRequestDispatcher("/change.jsp").forward(req,resp);
            return;
        }else {
            Integer x = memberService.changePassword(username,oldPassword,newPassword);
            if(x == 0){
                req.setAttribute("changeError","原密码错误");
                req.getRequestDispatcher("/change.jsp").forward(req,resp);
                return;
            }else if(!PasswordUtils.isPasswordComplex(newPassword)){
                req.setAttribute("changeError", "新密码复杂度不够");
                req.getRequestDispatcher("/change.jsp").forward(req, resp);
                return;
            }
            else {
                memberService.clearLoginCount(username);
                req.getRequestDispatcher("/login.jsp").forward(req,resp);
                return;
            }
        }
    }
}
