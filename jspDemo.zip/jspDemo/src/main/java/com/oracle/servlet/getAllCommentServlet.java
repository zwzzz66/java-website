package com.oracle.servlet;

import com.oracle.pojo.Message;
import com.oracle.pojo.User;
import com.oracle.service.MemberService;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/getAllCommentServlet")
public class getAllCommentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json; charset=UTF-8");
        MemberService memberService = new MemberService();
        List<Message> messageList = memberService.getAllComments();

        if (messageList.isEmpty()) {
            resp.getWriter().print("[]");
            return;
        }

        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < messageList.size(); i++) {
            Message message = messageList.get(i);
            json.append("{")
                    .append("\"username\":\"").append(escapeJson(message.getUsername())).append("\",")
                    .append("\"comment\":\"").append(escapeJson(message.getComment())).append("\",")
                    .append("\"time\":\"").append(escapeJson(message.getTime())).append("\"")
                    .append("}");
            if (i < messageList.size() - 1) json.append(",");
        }
        json.append("]");

        PrintWriter out = resp.getWriter();
        out.print(json.toString());
        out.flush();
    }

    private String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
