package com.oracle.servlet;

import com.oracle.pojo.PrivateMessage;
import com.oracle.service.MemberService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/addPrivateMessageServlet")
public class addPrivateMessageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        MemberService memberService = new MemberService();
        PrivateMessage privateMessage = new PrivateMessage();
        String sendUsername =(String) session.getAttribute("username");
        String receiveUsername = req.getParameter("receiveUsername");
        String comment = req.getParameter("comment");
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = df.format(date);
        privateMessage.setSendUsername(sendUsername);
        privateMessage.setReceiveUsername(receiveUsername);
        privateMessage.setComment(comment);
        privateMessage.setTime(time);
        memberService.addPrivateMessage(privateMessage);

        List<PrivateMessage> privateMessageList = memberService.getPrivateMessage(sendUsername,receiveUsername);
        req.setAttribute("privateMessageList",privateMessageList);
        req.setAttribute("user2",receiveUsername);
        req.getRequestDispatcher("privateChat.jsp").forward(req,resp);
    }
}
