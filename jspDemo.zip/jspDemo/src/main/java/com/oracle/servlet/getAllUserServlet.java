package com.oracle.servlet;

import com.oracle.pojo.Member;
import com.oracle.pojo.User;
import com.oracle.service.MemberService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/getAllUserServlet")
public class getAllUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Member member =(Member) session.getAttribute("memberInfo");
        String username = member.getName();
        MemberService memberService = new MemberService();
        List<User> userList = memberService.getAllUsers();
        session.setAttribute("username",username);
        req.setAttribute("userList",userList);
        req.setAttribute("username",username);
        req.getRequestDispatcher("chatBox.jsp").forward(req,resp);
    }
}
