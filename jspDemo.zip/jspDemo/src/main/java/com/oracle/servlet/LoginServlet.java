package com.oracle.servlet;

import com.oracle.pojo.Member;
import com.oracle.service.MemberService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userName = req.getParameter("username");
        String pwd = req.getParameter("password");
        String code = req.getParameter("code");

        HttpSession session = req.getSession();
        Integer maxLogin = (Integer) session.getAttribute("maxLogin");
        String sessionCode = (String) session.getAttribute("valcode");
        System.out.println(maxLogin);
        if (maxLogin <= 0){
            req.setAttribute("captError","尝试次数过多，请5分钟后在登录");
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
            return;
        }

        if (code == null || "".equals(code) || !code.equals(sessionCode)){
            session.setAttribute("maxLogin",maxLogin - 1);
            req.setAttribute("captError","验证码错误");
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
            return;
        }

        System.out.println(userName+"|"+pwd);
        Member member = new Member();
        member.setName(userName);
        member.setPwd(pwd);
        MemberService memberService = new MemberService();

        Integer count = memberService.selectLoginCount(userName);
        if (memberService.login(member)){
            if (count >= 5){
                req.setAttribute("loginError","已登录五次，请修改密码");
                req.getRequestDispatcher("login.jsp").forward(req,resp);
                return;
            } else {
                memberService.addLoginCount(userName);
                session.setAttribute("memberInfo",member);
                session.setAttribute("username",member.getName());
                resp.sendRedirect(req.getContextPath()+"/index.jsp");
                System.out.println(member);
                return;
            }
        }
        session.setAttribute("maxLogin",maxLogin - 1);
        req.setAttribute("loginError","用户不存在或密码错误");
        req.getRequestDispatcher("login.jsp").forward(req,resp);
        return;
    }
}
