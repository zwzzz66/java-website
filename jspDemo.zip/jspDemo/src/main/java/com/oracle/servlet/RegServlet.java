package com.oracle.servlet;


import com.oracle.pojo.Member;
import com.oracle.service.MemberService;
import com.oracle.utils.PasswordUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/doRegServlet")
public class RegServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String username = req.getParameter("username");
        String pwd = req.getParameter("password");
        String email = req.getParameter("email");
        String userCode = req.getParameter("userCode");
        String code = (String) session.getAttribute("emailCode");
        MemberService memberService = new MemberService();
        Member member = new Member();
        member.setName(username);
        member.setPwd(pwd);
        member.setEmail(email);
        System.out.println(code);
        System.out.println(userCode);

        if (!PasswordUtils.isPasswordComplex(pwd)){
            req.setAttribute("regError", "密码复杂度不够");
            req.getRequestDispatcher("/reg.jsp").forward(req, resp);
            return;
        }
        int i = memberService.register(member);
        if (i!=0){
            req.setAttribute("regError","账户已存在");
            req.getRequestDispatcher("/reg.jsp").forward(req,resp);
            return;
        }

        if(i == 0 && PasswordUtils.isPasswordComplex(pwd)){
            req.getRequestDispatcher(req.getContextPath()+"/goLoginViewServlet");
            return;
        }


    }
}
