package com.oracle.servlet;

import com.oracle.pojo.Member;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/goChatBoxViewServlet")
public class goChatBoxViewServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Member member = (Member) session.getAttribute("memberInfo");
        System.out.print(member);
        if (member == null){
            req.setAttribute("chatError","请先登录");
            resp.sendRedirect(req.getContextPath()+"/goLoginViewServlet");
        }else {
            resp.sendRedirect(req.getContextPath()+"/chatBox.jsp");
        }
    }
}
