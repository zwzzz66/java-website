package com.oracle.servlet;

import com.oracle.service.MemberService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/addCommentServlet")
public class addCommentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession session = req.getSession();
        String username =(String) session.getAttribute("username");
        System.out.print(username);
        System.out.print(username);
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateTime = df.format(date);
        String comment = req.getParameter("comment");
        String time = dateTime;
        MemberService memberService = new MemberService();
        memberService.InsertComment(username,comment,time);
        req.getRequestDispatcher("chatBox.jsp").forward(req,resp);
    }
}
