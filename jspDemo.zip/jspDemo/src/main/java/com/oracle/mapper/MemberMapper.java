package com.oracle.mapper;

import com.oracle.pojo.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MemberMapper {

    int selectMemberCountByUserName(String userName);

    void insertMember(Member member);

    Member selectMemberByUserName(String username);

    void insertVerificationToken(VerificationToken token);

    VerificationToken selectToken(String token);

    void updateUserStatus(int userId, String status);

    void changePassword(@Param(value = "username") String username,@Param(value = "password") String password);

    String getOldPassword(String username);

    void addLoginCount(String username);

    void clearLoginCount(String username);

    Integer selectLoginCount(String username);

    void InsertComment(Message message);

    List<Message> getAllComment();

    List<User> getAllUsers();

    List<PrivateMessage> getPrivateMessage(PrivateUser privateUser);

    void addPrivateMessage(PrivateMessage privateMessage);
}
