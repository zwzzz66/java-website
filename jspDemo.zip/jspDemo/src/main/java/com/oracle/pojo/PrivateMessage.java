package com.oracle.pojo;

public class PrivateMessage {
    Integer id;
    String sendUsername;
    String receiveUsername;
    String comment;
    String time;

    public PrivateMessage() {
    }

    public PrivateMessage(Integer id, String sendUsername, String receiveUsername, String comment, String time) {
        this.id = id;
        this.sendUsername = sendUsername;
        this.receiveUsername = receiveUsername;
        this.comment = comment;
        this.time = time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSendUsername() {
        return sendUsername;
    }

    public void setSendUsername(String sendUsername) {
        this.sendUsername = sendUsername;
    }

    public String getReceiveUsername() {
        return receiveUsername;
    }

    public void setReceiveUsername(String receiveUsername) {
        this.receiveUsername = receiveUsername;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "PrivateMessage{" +
                "id=" + id +
                ", sendUsername='" + sendUsername + '\'' +
                ", receiveUsername='" + receiveUsername + '\'' +
                ", comment='" + comment + '\'' +
                ", time='" + time + '\'' +
                '}';
    }
}
