package com.oracle.pojo;

public class VerificationToken {
    private Integer userId;
    private String token;

    public VerificationToken() {
    }

    public VerificationToken(Integer userId, String token) {
        this.userId = userId;
        this.token = token;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "VerificationToken{" +
                "userId=" + userId +
                ", token='" + token + '\'' +
                '}';
    }
}

